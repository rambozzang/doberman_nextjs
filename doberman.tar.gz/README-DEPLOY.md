# 도배맨 서버 배포 가이드

## 배포 방법

1. **서버에 파일 업로드**
   ```bash
   scp doberman.tar.gz user@server:/path/to/deploy/
   ```

2. **서버에서 압축 해제**
   ```bash
   tar -xzf doberman.tar.gz
   cd doberman-deploy
   ```

3. **배포 스크립트 실행**
   ```bash
   chmod +x deploy-server.sh
   ./deploy-server.sh
   ```

## 환경 변수 설정

배포 전에 필요한 환경 변수를 `.env.production` 파일에 설정하세요:

```env
NEXT_PUBLIC_BASE_URL=https://www.doberman.kr
GOOGLE_VERIFICATION_ID=your_google_verification_id
NAVER_VERIFICATION_ID=your_naver_verification_id
```

## 서버 요구사항

- Node.js 18.x 이상
- PM2 (프로세스 관리자)
- 최소 2GB RAM
- 최소 10GB 디스크 공간

## 유용한 명령어

- 상태 확인: `pm2 status`
- 로그 확인: `pm2 logs doberman`
- 재시작: `pm2 restart doberman`
- 중지: `pm2 stop doberman`
- 모니터링: `pm2 monit`

## 문제 해결

1. **포트 충돌**: 기본 포트는 3000입니다. 변경이 필요한 경우 `PORT` 환경 변수를 설정하세요.
2. **메모리 부족**: PM2 설정에서 메모리 제한을 조정하세요.
3. **빌드 오류**: `npm run build`를 다시 실행해보세요.
