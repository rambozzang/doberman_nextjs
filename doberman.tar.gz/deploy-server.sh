#!/bin/bash

echo "🚀 도배맨 서버 배포를 시작합니다..."

# PM2가 설치되어 있는지 확인
if ! command -v pm2 &> /dev/null; then
    echo "PM2가 설치되어 있지 않습니다. 설치를 진행합니다..."
    npm install -g pm2
fi

# 의존성 설치 (프로덕션 모드)
echo "📦 프로덕션 의존성을 설치합니다..."
npm ci --only=production

# 기존 프로세스 중지 (있는 경우)
pm2 stop doberman 2>/dev/null || true
pm2 delete doberman 2>/dev/null || true

# 새 프로세스 시작 (최적화된 설정 사용)
echo "🔄 애플리케이션을 시작합니다..."
if [ -f "ecosystem-optimized.config.js" ]; then
    echo "🚀 최적화된 PM2 설정으로 시작합니다..."
    pm2 start ecosystem-optimized.config.js --env production
else
    echo "⚠️  기본 PM2 설정으로 시작합니다..."
    pm2 start npm --name "doberman" -- start
fi

# PM2 설정 저장
pm2 save
pm2 startup

echo "✅ 배포가 완료되었습니다!"
echo ""
echo "📊 상태 확인: pm2 status"
echo "📋 로그 확인: pm2 logs doberman"
echo "🔍 모니터링: pm2 monit"
echo ""
echo "🎯 성능 최적화 적용 방법:"
echo "   1. Nginx 설정: sudo cp nginx-doberman-performance.conf /etc/nginx/sites-available/doberman.kr"
echo "   2. Nginx 재로드: sudo nginx -t && sudo systemctl reload nginx"
echo "   3. 모니터링 시작: ./monitoring-script.sh start"
echo "   4. 자세한 가이드: PERFORMANCE_GUIDE.md 참조"
